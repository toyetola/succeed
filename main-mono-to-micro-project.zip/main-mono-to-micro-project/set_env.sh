# This file is used for convenience of local development.
# DO NOT STORE YOUR CREDENTIALS INTO GIT
export POSTGRES_USERNAME=udagramadekunle
export POSTGRES_PASSWORD=udagramadekunle
export POSTGRES_HOST=udagramadekunle.c8vgvcci2rgd.us-east-1.rds.amazonaws.com
export POSTGRES_DB=postgres
export AWS_BUCKET=udagram-adekunle
export AWS_REGION=us-east-1
export AWS_PROFILE=default
export JWT_SECRET=testing
export URL=http://localhost:8100
