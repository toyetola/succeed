export const config = {
  "dev": {
    "username": "udagramadekunle",
    "password": "udagramadekunle",
    "database": "postgres",
    "host": "udagramadekunle.c8vgvcci2rgd.us-east-1.rds.amazonaws.com",
    "dialect": "postgres",
    "aws_region": "us-east-1",
    "aws_profile": "default",
    "aws_media_bucket": "udagram-adekunle"
  },
  "jwt": {
    "secret": " "
  },
  "prod": {
    "username": "",
    "password": "",
    "database": "udagram_prod",
    "host": "",
    "dialect": "postgres"
  }
}
